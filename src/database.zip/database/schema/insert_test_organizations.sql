-- Create users linked to the existing organizations (if they don't already exist)
-- User for Sender Org 1 (7351053399)
INSERT INTO users (full_name, phone, email, status, kyc_status)
VALUES ('Sender User 1', '7351053399', 'sender1@test.com', 'active', 'verified')
ON CONFLICT (phone) DO NOTHING;

-- User for Receiver Org 1 (8791984286)
INSERT INTO users (full_name, phone, email, status, kyc_status)
VALUES ('Receiver User 1', '8791984286', 'receiver1@test.com', 'active', 'verified')
ON CONFLICT (phone) DO NOTHING;

-- User for Sender Org 2 (9876543210)
INSERT INTO users (full_name, phone, email, status, kyc_status)
VALUES ('Sender User 2', '9876543210', 'sender2@test.com', 'active', 'verified')
ON CONFLICT (phone) DO NOTHING;

-- User for Receiver Org 2 (9123456789)
INSERT INTO users (full_name, phone, email, status, kyc_status)
VALUES ('Receiver User 2', '9123456789', 'receiver2@test.com', 'active', 'verified')
ON CONFLICT (phone) DO NOTHING;

-- Link users to organizations (ignore if already linked)
INSERT INTO organization_users (organization_id, user_id, organization_role, can_create_shipments, can_approve_shipments, is_active)
SELECT '50d2194e-a86b-4aba-919a-e01fba1c0c39', id, 'admin', TRUE, TRUE, TRUE FROM users WHERE phone = '7351053399'
UNION ALL
SELECT 'b148bc03-fbc8-4127-8de9-e6c2dbcc46f8', id, 'admin', TRUE, TRUE, TRUE FROM users WHERE phone = '8791984286'
UNION ALL
SELECT '8a0534db-57b7-4d50-af6a-e0e18d93fdc4', id, 'admin', TRUE, TRUE, TRUE FROM users WHERE phone = '9876543210'
UNION ALL
SELECT 'd2061232-71d9-4d2a-9eb0-9b0fd06561c7', id, 'admin', TRUE, TRUE, TRUE FROM users WHERE phone = '9123456789'
ON CONFLICT (organization_id, user_id) DO NOTHING;

-- ========== TWO NEW ORGANIZATIONS WITH EVERYTHING NEW ==========

-- Create two new organizations
INSERT INTO organizations (id, name, organization_type, primary_contact_name, primary_contact_phone, primary_contact_email, address_line1, city, state, postal_code, country, status, verified)
VALUES 
  ('a5c3f1d2-e8b9-4c7a-b2f1-d9a8c7b6a5e4', 'Premium Logistics Ltd', 'company', 'Rajesh Kumar', '9988776655', 'rajesh@premiumlogistics.com', '500 Business Park', 'Hyderabad', 'Telangana', '500001', 'India', 'active', TRUE),
  ('f7e2d1c3-a9b8-4f6e-c3a2-e8d7c6b5a4f3', 'Swift Delivery Services', 'company', 'Priya Sharma', '9876543201', 'priya@swiftdelivery.com', '789 Commerce Street', 'Pune', 'Maharashtra', '411001', 'India', 'active', TRUE);

-- Create users for the new organizations
INSERT INTO users (full_name, phone, email, status, kyc_status)
VALUES 
  ('Rajesh Kumar', '9988776655', 'rajesh@premiumlogistics.com', 'active', 'verified'),
  ('Priya Sharma', '9876543201', 'priya@swiftdelivery.com', 'active', 'verified')
ON CONFLICT (phone) DO NOTHING;

-- Create default addresses for the new organizations
INSERT INTO addresses (owner_type, owner_id, label, contact_person_name, contact_phone, address_line1, city, state, postal_code, country, is_default, is_active)
VALUES 
  ('organization', 'a5c3f1d2-e8b9-4c7a-b2f1-d9a8c7b6a5e4', 'Main Warehouse', 'Rajesh Kumar', '9988776655', '500 Business Park', 'Hyderabad', 'Telangana', '500001', 'India', TRUE, TRUE),
  ('organization', 'f7e2d1c3-a9b8-4f6e-c3a2-e8d7c6b5a4f3', 'Distribution Center', 'Priya Sharma', '9876543201', '789 Commerce Street', 'Pune', 'Maharashtra', '411001', 'India', TRUE, TRUE);

-- Link new users to their organizations
INSERT INTO organization_users (organization_id, user_id, organization_role, can_create_shipments, can_approve_shipments, is_active)
SELECT 'a5c3f1d2-e8b9-4c7a-b2f1-d9a8c7b6a5e4', id, 'admin', TRUE, TRUE, TRUE FROM users WHERE phone = '9988776655'
UNION ALL
SELECT 'f7e2d1c3-a9b8-4f6e-c3a2-e8d7c6b5a4f3', id, 'admin', TRUE, TRUE, TRUE FROM users WHERE phone = '9876543201'
ON CONFLICT (organization_id, user_id) DO NOTHING;
