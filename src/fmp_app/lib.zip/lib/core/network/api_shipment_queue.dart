import 'package:dio/dio.dart';
import '../models/shipment.dart';
import 'api_client.dart';

class ShipmentApiService {
  final ApiClient _client;
  ShipmentApiService(this._client);
  Dio get _dio => _client.dio;

  // Queue screen: GET /api/shipment-queue
  Future<PagedResult<Shipment>> fetchQueue({int page=1, int pageSize=20}) async {
    final res = await _dio.get('/api/shipment-queue',
        queryParameters: {'page': page, 'pageSize': pageSize});
    return PagedResult.fromJson(res.data, Shipment.fromJson);
  }

  // Driver accepts: POST /api/shipment-queue/{id}/accept
  // Returns true on success, false on 409 (already taken)
  Future<bool> acceptShipment({required String shipmentId, required String driverId}) async {
    try {
      await _dio.post('/api/shipment-queue/$shipmentId/accept',
          data: {'driverId': driverId});
      return true;
    } on DioException catch (e) {
      if (e.response?.statusCode == 409) return false;
      rethrow;
    }
  }

  // Detail screen: GET /api/shipment-queue/{id}
  Future<Shipment> getQueueItemById(String id) async {
    final res = await _dio.get('/api/shipment-queue/$id');
    return Shipment.fromJson(res.data);
  }
}

