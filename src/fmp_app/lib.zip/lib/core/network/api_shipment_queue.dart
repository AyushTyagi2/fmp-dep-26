import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import '../models/shipment.dart';
import 'api_client.dart';

// ─── DateTime helper ──────────────────────────────────────────────────────────

DateTime _parseUtc(String raw) {
  final normalized = raw.endsWith('Z') || raw.contains('+') ? raw : '${raw}Z';
  return DateTime.parse(normalized).toLocal();
}

// ─── Result types ─────────────────────────────────────────────────────────────

class AcceptResult {
  final bool    success;
  final bool    wasTaken;
  final String? tripId;
  final String? message;
  const AcceptResult({
    required this.success,
    this.wasTaken = false,
    this.tripId,
    this.message,
  });
}

class PassResult {
  final bool       success;
  final String?    message;
  final QueueSlot? nextSlot;
  const PassResult({required this.success, this.message, this.nextSlot});
}

// ─── ShipmentSlotItem — one entry in the driver's ordered list ───────────────
//
// The new backend sends a flat list of all shipments.
// Flutter derives UI state from:
//   index < claimableCount  → actionable (Accept shown)
//     isExpired = false     → active window, show countdown
//     isExpired = true      → amber "Still Claimable", no timer
//   index >= claimableCount → locked "Up Next"

class ShipmentSlotItem {
  final String   shipmentQueueId;
  final String   shipmentId;
  final String   shipmentNumber;
  final String   pickupLocation;
  final String   dropLocation;
  final String   cargoType;
  final double   cargoWeightKg;
  final double?  agreedPrice;
  final bool     isUrgent;
  final bool     isExpired;      // true = amber still-claimable, no countdown
  final DateTime? expiresAt;    // non-null only when active window is running

  const ShipmentSlotItem({
    required this.shipmentQueueId,
    required this.shipmentId,
    required this.shipmentNumber,
    required this.pickupLocation,
    required this.dropLocation,
    required this.cargoType,
    required this.cargoWeightKg,
    this.agreedPrice,
    required this.isUrgent,
    required this.isExpired,
    this.expiresAt,
  });

  factory ShipmentSlotItem.fromJson(Map<String, dynamic> json) => ShipmentSlotItem(
    shipmentQueueId : json['shipmentQueueId'].toString(),
    shipmentId      : json['shipmentId'].toString(),
    shipmentNumber  : json['shipmentNumber']  as String,
    pickupLocation  : json['pickupLocation']  as String,
    dropLocation    : json['dropLocation']    as String,
    cargoType       : json['cargoType']       as String,
    cargoWeightKg   : (json['cargoWeightKg']  as num).toDouble(),
    agreedPrice     : json['agreedPrice'] != null
                        ? (json['agreedPrice'] as num).toDouble()
                        : null,
    isUrgent        : json['isUrgent']   as bool,
    isExpired       : json['isExpired']  as bool,
    expiresAt       : json['expiresAt'] != null
                        ? _parseUtc(json['expiresAt'] as String)
                        : null,
  );

  Duration get timeRemaining {
    if (expiresAt == null) return Duration.zero;
    final diff = expiresAt!.difference(DateTime.now());
    return diff.isNegative ? Duration.zero : diff;
  }
}

// ─── QueueSlot — the driver's full queue state ────────────────────────────────

class QueueSlot {
  final String                eventId;
  final String                eventStatus;
  final DateTime              eventEndTime;
  final int                   position;
  final bool                  hasClaimed;
  final int                   claimableCount;
  final List<ShipmentSlotItem> shipmentSlots;  // ordered, skipped items removed

  const QueueSlot({
    required this.eventId,
    required this.eventStatus,
    required this.eventEndTime,
    required this.position,
    required this.hasClaimed,
    required this.claimableCount,
    this.shipmentSlots = const [],
  });

  factory QueueSlot.fromJson(Map<String, dynamic> json) {
    debugPrint('[QueueSlot.fromJson] raw keys: ${json.keys.toList()}');
    return QueueSlot(
      eventId        : json['eventId'].toString(),
      eventStatus    : json['eventStatus'].toString(),
      eventEndTime   : _parseUtc(json['eventEndTime'].toString()),
      position       : (json['position'] as num).toInt(),
      hasClaimed     : json['hasClaimed'] as bool,
      claimableCount : (json['claimableCount'] as num).toInt(),
      shipmentSlots  : (json['shipmentSlots'] as List<dynamic>? ?? [])
          .map((e) => ShipmentSlotItem.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  // ── Derived state for UI ──────────────────────────────────────────────────

  /// Shipments the driver can currently act on (Accept/Claim buttons shown).
  List<ShipmentSlotItem> get claimableSlots =>
      shipmentSlots.take(claimableCount).toList();

  /// The single slot with an active countdown (the newest non-expired claimable).
  /// Null when there are no active windows (all claimable are amber, or none at all).
  ShipmentSlotItem? get activeWindowSlot {
    // Last claimable that hasn't expired = the freshest active window
    final claimable = claimableSlots;
    try {
      return claimable.lastWhere((s) => !s.isExpired);
    } catch (_) {
      return null;
    }
  }

  /// Amber "Still Claimable" slots — timer gone but still actionable.
  List<ShipmentSlotItem> get stillClaimableSlots =>
      claimableSlots.where((s) => s.isExpired).toList();

  /// Locked "Up Next" preview slots.
  List<ShipmentSlotItem> get upcomingSlots =>
      shipmentSlots.skip(claimableCount).toList();

  /// True when the driver has at least one offer card to show.
  bool get hasActiveOffer => claimableCount > 0 && shipmentSlots.isNotEmpty;

  /// True when the event is live and driver is waiting (no offers yet / in between).
  bool get isWaiting => eventStatus == 'live' && claimableCount == 0 && !hasClaimed;

  /// True if the driver has already accepted a shipment in this event.
  bool get hasAlreadyClaimed => hasClaimed;
}

// ─── Paged result (unchanged) ─────────────────────────────────────────────────

class PagedResult<T> {
  final List<T> items;
  final int     page;
  final int     totalPages;
  const PagedResult({required this.items, required this.page, required this.totalPages});

  factory PagedResult.fromJson(
    Map<String, dynamic> json,
    T Function(Map<String, dynamic>) fromJson,
  ) => PagedResult(
    items      : (json['items'] as List).map((e) => fromJson(e as Map<String, dynamic>)).toList(),
    page       : json['page']       as int,
    totalPages : json['totalPages'] as int,
  );
}

// ─── API service ──────────────────────────────────────────────────────────────

class ShipmentApiService {
  final ApiClient _client;
  ShipmentApiService(this._client);
  Dio get _dio => _client.dio;

  Future<PagedResult<Shipment>> fetchQueue({int page = 1, int pageSize = 20}) async {
    final res = await _dio.get(
      '/api/shipment-queue',
      queryParameters: {'page': page, 'pageSize': pageSize},
    );
    return PagedResult.fromJson(res.data as Map<String, dynamic>, Shipment.fromJson);
  }

  Future<QueueSlot?> getMyQueueSlot(String driverId) async {
    final res  = await _dio.get(
      '/api/queue-events/active',
      queryParameters: {'driverId': driverId},
    );
    final data = res.data as Map<String, dynamic>;
    debugPrint('[getMyQueueSlot] active=${data['active']}  claimableCount=${data['claimableCount']}  slots=${(data['shipmentSlots'] as List?)?.length}');
    if (data['active'] != true) return null;
    return QueueSlot.fromJson(data);
  }

  Future<AcceptResult> acceptShipment({
    required String shipmentQueueId,
    required String driverId,
  }) async {
    try {
      final res  = await _dio.post(
        '/api/shipment-queue/$shipmentQueueId/accept',
        data: {'driverId': driverId},
      );
      final data = res.data as Map<String, dynamic>;
      return AcceptResult(
        success : data['success'] as bool,
        tripId  : data['tripId']  as String?,
        message : data['message'] as String?,
      );
    } on DioException catch (e) {
      if (e.response?.statusCode == 409) {
        return const AcceptResult(success: false, wasTaken: true, message: 'Already taken by another driver.');
      }
      final msg = (e.response?.data as Map<String, dynamic>?)?['message'] as String?
          ?? e.message
          ?? 'Could not accept shipment. Please try again.';
      debugPrint('[acceptShipment] DioException ${e.response?.statusCode}: $msg');
      return AcceptResult(success: false, message: msg);
    } catch (e) {
      debugPrint('[acceptShipment] unexpected error: $e');
      return const AcceptResult(success: false, message: 'Network error. Please try again.');
    }
  }

  Future<PassResult> passShipment({
    required String shipmentQueueId,
    required String driverId,
  }) async {
    try {
      final res  = await _dio.post(
        '/api/shipment-queue/$shipmentQueueId/pass',
        data: {'driverId': driverId},
      );
      final data = res.data as Map<String, dynamic>;

      QueueSlot? nextSlot;
      final rawSlot = data['nextSlot'];
      if (rawSlot != null && rawSlot is Map<String, dynamic> && rawSlot['active'] == true) {
        debugPrint('[passShipment] nextSlot present — applying inline');
        nextSlot = QueueSlot.fromJson(rawSlot);
      }

      return PassResult(
        success  : data['success'] as bool,
        message  : data['message'] as String?,
        nextSlot : nextSlot,
      );
    } on DioException catch (e) {
      return PassResult(
        success : false,
        message : e.response?.data?['message'] as String? ?? 'Failed to pass.',
      );
    }
  }

  Future<Shipment> getQueueItemById(String id) async {
    final res = await _dio.get('/api/shipment-queue/$id');
    return Shipment.fromJson(res.data as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> getQueueLiveStatus() async {
    debugPrint('[getQueueLiveStatus] → GET /api/queue-events/live-status');
    try {
      final res  = await _dio.get('/api/queue-events/live-status');
      final data = res.data as Map<String, dynamic>;
      debugPrint('[getQueueLiveStatus] eventId=${data['eventId']}  isLive=${data['isLive']}');
      return data;
    } on DioException catch (e) {
      debugPrint('[getQueueLiveStatus] ❌ DioException — status: ${e.response?.statusCode}  body: ${e.response?.data}');
      rethrow;
    }
  }

  /// Creates a new queue event.
  /// Called by the union-side _CreateQueueSheet when going live for the first time.
  /// POST /api/queue-events
  Future<void> createQueueEvent({
    required double durationHours,
    required int    windowSeconds,
    String?         zoneId,
  }) async {
    try {
      await _dio.post(
        '/api/queue-events',
        data: {
          'durationHours' : durationHours,
          'windowSeconds' : windowSeconds,
          if (zoneId != null) 'zoneId': zoneId.toString(),
        },
      );
    } on DioException catch (e) {
      // 409 = a live event already exists — surface a clean message to the UI
      final msg = (e.response?.data is Map)
          ? (e.response!.data as Map)['message'] as String? ?? 'A queue event is already active.'
          : 'A queue event is already active.';
      throw Exception(msg);
    }
  }

  Future<Map<String, dynamic>> toggleQueueEvent(String eventId) async {
    final res = await _dio.post('/api/queue-events/$eventId/toggle');
    return res.data as Map<String, dynamic>;
  }

  /// Fetches all queue events (past + current), newest first.
  /// GET /api/queue-events
  Future<List<Map<String, dynamic>>> getAllQueueEvents() async {
    final res  = await _dio.get('/api/queue-events');
    final data = res.data;
    if (data is List) {
      return data.cast<Map<String, dynamic>>();
    }
    // Some backends wrap in { items: [...] }
    if (data is Map<String, dynamic> && data['items'] is List) {
      return (data['items'] as List).cast<Map<String, dynamic>>();
    }
    return [];
  }
}