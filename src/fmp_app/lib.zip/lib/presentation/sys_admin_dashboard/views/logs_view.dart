import 'package:flutter/material.dart';
import '../sys_admin_api.dart';

class LogsView extends StatefulWidget {
  const LogsView({super.key});

  @override
  State<LogsView> createState() => _LogsViewState();
}

class _LogsViewState extends State<LogsView> {
  final _api = SysAdminApi();

  List<dynamic> _allLogs   = [];
  String _filter           = 'All Logs';
  bool _loading            = true;
  String? _error;

  static const _filters = ['All Logs', 'force_assigned', 'cancel', 'approve', 'reject'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final logs = await _api.getLogs(limit: 100);
      setState(() { _allLogs = logs; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  List<dynamic> get _filtered {
    if (_filter == 'All Logs') return _allLogs;
    return _allLogs.where((l) {
      final et = (l['eventType'] as String? ?? '').toLowerCase();
      return et.contains(_filter.toLowerCase());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // ── Filter bar ─────────────────────────────────────────────────────────
      Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: _filters.map((f) {
                final selected = _filter == f;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () => setState(() => _filter = f),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: selected ? Colors.indigo : Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(f, style: TextStyle(
                        color: selected ? Colors.white : Colors.grey.shade700,
                        fontWeight: selected ? FontWeight.bold : FontWeight.w500,
                        fontSize: 13,
                      )),
                    ),
                  ),
                );
              }).toList()),
            ),
          ),
          const SizedBox(width: 8),
          TextButton.icon(
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('Refresh'),
            style: TextButton.styleFrom(foregroundColor: Colors.indigo),
            onPressed: _load,
          ),
        ]),
      ),
      const Divider(height: 1),

      // ── Body ───────────────────────────────────────────────────────────────
      Expanded(child: () {
        if (_loading) return const Center(child: CircularProgressIndicator());
        if (_error != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, color: Colors.red, size: 48),
          const SizedBox(height: 12),
          Text(_error!, style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: _load, child: const Text('Retry')),
        ]));
        final logs = _filtered;
        if (logs.isEmpty) return Center(child: Text('No logs for "$_filter"', style: TextStyle(color: Colors.grey.shade500)));

        return RefreshIndicator(
          onRefresh: _load,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: logs.length,
            itemBuilder: (context, i) {
              final log       = logs[i] as Map<String, dynamic>;
              final eventType = log['eventType']?.toString() ?? '';
              final actorType = log['actorType']?.toString() ?? '';
              final entityId  = log['entityId']?.toString() ?? '';
              final createdAt = log['createdAt']?.toString() ?? '';
              final timeLabel = createdAt.length >= 19 ? createdAt.substring(0, 19).replaceFirst('T', ' ') : createdAt;

              Color statusColor; Color bgColor; IconData icon;
              if (eventType.contains('cancel') || eventType.contains('reject')) {
                statusColor = Colors.red; bgColor = Colors.red.shade50; icon = Icons.cancel_outlined;
              } else if (eventType.contains('force')) {
                statusColor = Colors.orange; bgColor = Colors.orange.shade50; icon = Icons.warning_amber;
              } else if (eventType.contains('approve')) {
                statusColor = Colors.green; bgColor = Colors.green.shade50; icon = Icons.check_circle_outline;
              } else {
                statusColor = Colors.blue; bgColor = Colors.blue.shade50; icon = Icons.info_outline;
              }

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: bgColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 4, offset: const Offset(0, 2))],
                ),
                child: IntrinsicHeight(
                  child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Container(
                      width: 4,
                      decoration: BoxDecoration(color: statusColor,
                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(12), bottomLeft: Radius.circular(12))),
                    ),
                    Expanded(child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Icon(icon, color: statusColor, size: 18),
                          const SizedBox(width: 8),
                          Expanded(child: Text(eventType, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.black87), overflow: TextOverflow.ellipsis)),
                          const SizedBox(width: 8),
                          Text(timeLabel, style: TextStyle(fontFamily: 'monospace', color: Colors.grey.shade500, fontSize: 11)),
                        ]),
                        const SizedBox(height: 8),
                        Text('Entity: $entityId', style: TextStyle(color: Colors.grey.shade700, fontSize: 13)),
                        const SizedBox(height: 8),
                        Row(children: [
                          _Tag(text: actorType.isNotEmpty ? actorType : 'system'),
                          if (log['entityType'] != null) ...[const SizedBox(width: 8), _Tag(text: log['entityType'].toString())],
                        ]),
                      ]),
                    )),
                  ]),
                ),
              );
            },
          ),
        );
      }()),
    ]);
  }
}

class _Tag extends StatelessWidget {
  final String text;
  const _Tag({required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
    decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(4), border: Border.all(color: Colors.grey.shade300)),
    child: Text(text, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontFamily: 'monospace')),
  );
}