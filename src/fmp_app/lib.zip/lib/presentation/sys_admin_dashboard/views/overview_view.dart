import 'package:flutter/material.dart';
import '../sys_admin_api.dart';

class OverviewView extends StatefulWidget {
  const OverviewView({super.key});

  @override
  State<OverviewView> createState() => _OverviewViewState();
}

class _OverviewViewState extends State<OverviewView> {
  final _api = SysAdminApi();

  Map<String, dynamic>? _metrics;
  List<dynamic> _logs = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([_api.getMetrics(), _api.getLogs(limit: 10)]);
      setState(() {
        _metrics = results[0] as Map<String, dynamic>;
        _logs    = results[1] as List<dynamic>;
        _loading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline, color: Colors.red, size: 48),
        const SizedBox(height: 12),
        Text('Failed to load data', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 16),
        ElevatedButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Retry')),
      ]));
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Wrap(spacing: 16, runSpacing: 16, children: [
            _StatCard(title: 'Active Drivers',    value: '${_metrics!['activeDrivers']    ?? 0}', icon: Icons.local_taxi,           color: Colors.green),
            _StatCard(title: 'Pending Shipments', value: '${_metrics!['pendingShipments'] ?? 0}', icon: Icons.pending_actions,      color: Colors.orange),
            _StatCard(title: 'Active Trips',      value: '${_metrics!['activeTrips']      ?? 0}', icon: Icons.route,                color: Colors.purple),
            _StatCard(title: 'Admin Overrides',   value: '${_metrics!['adminOverrides']   ?? 0}', icon: Icons.admin_panel_settings, color: Colors.red),
          ]),
          const SizedBox(height: 32),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Recent System Activity', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
            TextButton.icon(onPressed: _load, icon: const Icon(Icons.refresh, size: 16), label: const Text('Refresh')),
          ]),
          const SizedBox(height: 12),
          if (_logs.isEmpty)
            Center(child: Padding(padding: const EdgeInsets.all(32), child: Text('No recent activity', style: TextStyle(color: Colors.grey.shade500))))
          else
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
              child: ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _logs.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, i) {
                  final log       = _logs[i] as Map<String, dynamic>;
                  final eventType = log['eventType']?.toString() ?? '';
                  final isWarning = eventType.contains('force') || eventType.contains('cancel');
                  final createdAt = log['createdAt']?.toString() ?? '';
                  final timeLabel = createdAt.length >= 16 ? createdAt.substring(0, 16).replaceFirst('T', ' ') : createdAt;
                  final entityId  = log['entityId']?.toString() ?? '';
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: isWarning ? Colors.orange.shade50 : Colors.blue.shade50, shape: BoxShape.circle),
                      child: Icon(isWarning ? Icons.priority_high : Icons.info_outline, size: 20, color: isWarning ? Colors.orange : Colors.blue),
                    ),
                    title: Text(eventType, style: const TextStyle(fontWeight: FontWeight.w500)),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(entityId.isNotEmpty ? 'Entity: $entityId' : '—', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                    ),
                    trailing: Text(timeLabel, style: TextStyle(color: Colors.grey.shade400, fontSize: 11)),
                  );
                },
              ),
            ),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title; final String value; final IconData icon; final Color color;
  const _StatCard({required this.title, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    final width = (MediaQuery.of(context).size.width - 48) / 2;
    return Container(
      width: width, padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 28)),
        const SizedBox(height: 16),
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87)),
        const SizedBox(height: 4),
        Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 13, fontWeight: FontWeight.w500)),
      ]),
    );
  }
}