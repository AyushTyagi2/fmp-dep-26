import 'package:flutter/material.dart';
import '../sys_admin_api.dart';

class QueueView extends StatefulWidget {
  const QueueView({super.key});

  @override
  State<QueueView> createState() => _QueueViewState();
}

class _QueueViewState extends State<QueueView> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  final _api = SysAdminApi();

  List<dynamic> _pending  = [];
  List<dynamic> _approved = [];
  List<dynamic> _all      = [];
  bool _loading            = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _load();
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([
        _api.getShipments(status: 'pending_approval'),
        _api.getShipments(status: 'approved'),
        _api.getShipments(),
      ]);
      setState(() {
        _pending  = results[0];
        _approved = results[1];
        _all      = results[2];
        _loading  = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _approve(String id) async {
    try {
      await _api.approveShipment(id);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shipment approved ✓'), backgroundColor: Colors.green));
      _load();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    }
  }

  Future<void> _reject(String id) async {
    final reason = await _showReasonDialog('Reject Shipment');
    if (reason == null) return;
    try {
      await _api.rejectShipment(id, reason);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shipment rejected'), backgroundColor: Colors.orange));
      _load();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    }
  }

  Future<void> _cancel(String id) async {
    final reason = await _showReasonDialog('Cancel Shipment');
    if (reason == null) return;
    try {
      await _api.cancelShipment(id, reason);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shipment cancelled'), backgroundColor: Colors.grey));
      _load();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    }
  }

  Future<String?> _showReasonDialog(String title) async {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'Enter reason…'), maxLines: 3),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, ctrl.text.trim()),
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // ── Header ─────────────────────────────────────────────────────────────
      Container(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        color: Colors.white,
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Shipment Queue', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('Review and action pending shipment requests.', style: TextStyle(color: Colors.grey.shade600)),
          ])),
          ElevatedButton.icon(
            onPressed: _load,
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('Refresh'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
          ),
        ]),
      ),
      TabBar(
        controller: _tabs,
        labelColor: Colors.indigo,
        unselectedLabelColor: Colors.grey,
        indicatorColor: Colors.indigo,
        tabs: [
          Tab(text: 'Pending (${_pending.length})'),
          Tab(text: 'Approved (${_approved.length})'),
          Tab(text: 'All (${_all.length})'),
        ],
      ),
      const Divider(height: 1),
      Expanded(child: () {
        if (_loading) return const Center(child: CircularProgressIndicator());
        if (_error != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, color: Colors.red, size: 48),
          const SizedBox(height: 12),
          Text(_error!, style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: _load, child: const Text('Retry')),
        ]));

        return TabBarView(controller: _tabs, children: [
          _ShipmentList(shipments: _pending,  onApprove: _approve, onReject: _reject, onCancel: _cancel),
          _ShipmentList(shipments: _approved, onApprove: null,     onReject: _reject, onCancel: _cancel),
          _ShipmentList(shipments: _all,      onApprove: _approve, onReject: _reject, onCancel: _cancel),
        ]);
      }()),
    ]);
  }
}

// ── Shipment list ─────────────────────────────────────────────────────────────

class _ShipmentList extends StatelessWidget {
  final List<dynamic> shipments;
  final void Function(String)? onApprove;
  final void Function(String) onReject;
  final void Function(String) onCancel;

  const _ShipmentList({required this.shipments, required this.onApprove, required this.onReject, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    if (shipments.isEmpty) {
      return Center(child: Text('No shipments', style: TextStyle(color: Colors.grey.shade500)));
    }
    return RefreshIndicator(
      onRefresh: () async {},
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: shipments.length,
        itemBuilder: (context, i) => _ShipmentCard(
          shipment:  shipments[i] as Map<String, dynamic>,
          onApprove: onApprove,
          onReject:  onReject,
          onCancel:  onCancel,
        ),
      ),
    );
  }
}

class _ShipmentCard extends StatelessWidget {
  final Map<String, dynamic> shipment;
  final void Function(String)? onApprove;
  final void Function(String) onReject;
  final void Function(String) onCancel;

  const _ShipmentCard({required this.shipment, required this.onApprove, required this.onReject, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    final id            = shipment['id']?.toString()             ?? '';
    final number        = shipment['shipmentNumber']?.toString() ?? id.substring(0, 8);
    final status        = shipment['status']?.toString()         ?? 'unknown';
    final origin        = shipment['originAddress']?.toString()  ?? '—';
    final dest          = shipment['destinationAddress']?.toString() ?? '—';
    final cargoType     = shipment['cargoType']?.toString()      ?? '—';
    final weight        = shipment['weightKg']?.toString()       ?? '—';
    final createdAt     = shipment['createdAt']?.toString()      ?? '';
    final dateLabel     = createdAt.length >= 10 ? createdAt.substring(0, 10) : createdAt;

    Color statusColor; IconData statusIcon;
    switch (status) {
      case 'pending_approval': statusColor = Colors.orange; statusIcon = Icons.hourglass_empty; break;
      case 'approved':         statusColor = Colors.green;  statusIcon = Icons.check_circle_outline; break;
      case 'cancelled':        statusColor = Colors.red;    statusIcon = Icons.cancel_outlined; break;
      case 'rejected':         statusColor = Colors.red;    statusIcon = Icons.block; break;
      case 'assigned':         statusColor = Colors.blue;   statusIcon = Icons.local_shipping; break;
      default:                 statusColor = Colors.grey;   statusIcon = Icons.info_outline;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 4))]),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header row
          Row(children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(4)),
              child: Text(number, style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.grey.shade800, fontWeight: FontWeight.bold))),
            const Spacer(),
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: statusColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
              child: Row(children: [
                Icon(statusIcon, size: 14, color: statusColor),
                const SizedBox(width: 4),
                Text(status.toUpperCase(), style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: statusColor, letterSpacing: 1)),
              ])),
          ]),
          const SizedBox(height: 14),
          // Route
          Row(children: [
            const Icon(Icons.circle, size: 10, color: Colors.green),
            const SizedBox(width: 8),
            Expanded(child: Text(origin, style: const TextStyle(fontSize: 13, color: Colors.black87), overflow: TextOverflow.ellipsis)),
          ]),
          Padding(padding: const EdgeInsets.only(left: 4), child: Container(height: 16, width: 2, color: Colors.grey.shade300)),
          Row(children: [
            const Icon(Icons.location_on, size: 10, color: Colors.red),
            const SizedBox(width: 8),
            Expanded(child: Text(dest, style: const TextStyle(fontSize: 13, color: Colors.black87), overflow: TextOverflow.ellipsis)),
          ]),
          const SizedBox(height: 12),
          // Meta chips
          Wrap(spacing: 8, children: [
            _Chip(icon: Icons.category_outlined, label: cargoType),
            _Chip(icon: Icons.scale_outlined,    label: '${weight}kg'),
            _Chip(icon: Icons.calendar_today,    label: dateLabel),
          ]),
          // Action buttons
          if (status == 'pending_approval' || status == 'approved') ...[
            const Divider(height: 24),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              if (status == 'pending_approval' && onApprove != null)
                TextButton.icon(
                  onPressed: () => onApprove!(id),
                  icon: const Icon(Icons.check, size: 18),
                  label: const Text('Approve'),
                  style: TextButton.styleFrom(foregroundColor: Colors.green),
                ),
              if (status == 'pending_approval')
                TextButton.icon(
                  onPressed: () => onReject(id),
                  icon: const Icon(Icons.close, size: 18),
                  label: const Text('Reject'),
                  style: TextButton.styleFrom(foregroundColor: Colors.red),
                ),
              TextButton.icon(
                onPressed: () => onCancel(id),
                icon: const Icon(Icons.cancel_outlined, size: 18),
                label: const Text('Cancel'),
                style: TextButton.styleFrom(foregroundColor: Colors.orange),
              ),
            ]),
          ],
        ]),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final IconData icon; final String label;
  const _Chip({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(8)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 12, color: Colors.grey.shade600),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
    ]),
  );
}