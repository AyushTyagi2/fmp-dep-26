import 'package:flutter/material.dart';
import '../sys_admin_api.dart';

class UsersView extends StatefulWidget {
  const UsersView({super.key});

  @override
  State<UsersView> createState() => _UsersViewState();
}

class _UsersViewState extends State<UsersView> {
  final _api        = SysAdminApi();
  List<dynamic> _allUsers  = [];
  List<dynamic> _displayed = [];
  bool _loading             = true;
  String? _error;
  final _searchCtrl         = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_applySearch);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final users = await _api.getUsers();
      setState(() { _allUsers = users; _displayed = users; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  void _applySearch() {
    final q = _searchCtrl.text.toLowerCase();
    setState(() {
      _displayed = q.isEmpty
          ? _allUsers
          : _allUsers.where((u) {
              final name  = (u['fullName']  as String? ?? '').toLowerCase();
              final phone = (u['phone']     as String? ?? '').toLowerCase();
              final id    = (u['id']        as String? ?? '').toLowerCase();
              return name.contains(q) || phone.contains(q) || id.contains(q);
            }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Expanded(
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search users by name, phone, or ID…',
                hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14),
                prefixIcon: Icon(Icons.search, color: Colors.grey.shade500),
                filled: true, fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide(color: Colors.grey.shade200)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide(color: Colors.indigo.shade300)),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade300)),
            child: IconButton(icon: const Icon(Icons.refresh, color: Colors.black87), onPressed: _load),
          ),
        ]),
      ),
      Expanded(child: () {
        if (_loading) return const Center(child: CircularProgressIndicator());
        if (_error != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, color: Colors.red, size: 48),
          const SizedBox(height: 12),
          Text(_error!, style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: _load, child: const Text('Retry')),
        ]));
        if (_displayed.isEmpty) return Center(child: Text('No users found', style: TextStyle(color: Colors.grey.shade500)));

        return RefreshIndicator(
          onRefresh: _load,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: _displayed.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, i) {
              final u        = _displayed[i] as Map<String, dynamic>;
              final fullName = u['fullName']?.toString() ?? 'Unknown';
              final phone    = u['phone']?.toString()    ?? '—';
              final id       = u['id']?.toString()       ?? '';
              final initials = fullName.split(' ').take(2).map((w) => w.isNotEmpty ? w[0] : '').join().toUpperCase();
              final createdAt = u['createdAt']?.toString() ?? '';
              final joined    = createdAt.length >= 10 ? createdAt.substring(0, 10) : createdAt;

              return Container(
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 4, offset: const Offset(0, 2))]),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: CircleAvatar(
                    backgroundColor: Colors.indigo.withOpacity(0.1),
                    child: Text(initials.isNotEmpty ? initials : '?', style: const TextStyle(color: Colors.indigo, fontWeight: FontWeight.bold)),
                  ),
                  title: Text(fullName, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Icon(Icons.phone, size: 13, color: Colors.grey.shade500),
                        const SizedBox(width: 4),
                        Text(phone, style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                      ]),
                      const SizedBox(height: 2),
                      Row(children: [
                        Icon(Icons.calendar_today, size: 13, color: Colors.grey.shade500),
                        const SizedBox(width: 4),
                        Text('Joined $joined', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
                      ]),
                    ]),
                  ),
                  trailing: PopupMenuButton<String>(
                    icon: Icon(Icons.more_vert, color: Colors.grey.shade500),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    onSelected: (value) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$value — $fullName')));
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(value: 'View Profile', child: Text('View Profile')),
                      const PopupMenuItem(value: 'Suspend Account', child: Text('Suspend Account')),
                      PopupMenuItem(value: 'Delete', child: Text('Delete', style: TextStyle(color: Colors.red.shade700))),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      }()),
    ]);
  }
}