import 'package:flutter/material.dart';
import '../../../core/network/api_shipment_queue.dart';
import '../../../shared/theme/app_theme.dart';

// ─────────────────────────────────────────────────────────────────────────────
// CREATE QUEUE EVENT SCREEN
// Full-page form: duration + driver window → POST /api/queue-events
// Returns true to caller on success so the events list can refresh.
// ─────────────────────────────────────────────────────────────────────────────

class CreateQueueEventScreen extends StatefulWidget {
  final ShipmentApiService api;
  const CreateQueueEventScreen({super.key, required this.api});

  @override
  State<CreateQueueEventScreen> createState() => _CreateQueueEventScreenState();
}

class _CreateQueueEventScreenState extends State<CreateQueueEventScreen> {
  double  _durationHours = 2.0;   // 0.5 – 12 h
  int     _windowMinutes = 2;     // 1 – 30 min
  bool    _submitting    = false;
  String? _error;

  // ── helpers ───────────────────────────────────────────────────────────────

  String _fmtDuration(double h) {
    if (h < 1) return '${(h * 60).round()} min';
    final int hrs  = h.floor();
    final int mins = ((h - hrs) * 60).round();
    if (mins == 0) return '$hrs hr${hrs > 1 ? 's' : ''}';
    return '$hrs hr $mins min';
  }

  String _fmtEndTime(double h) {
    final end = DateTime.now().add(Duration(minutes: (h * 60).round()));
    final hh  = end.hour.toString().padLeft(2, '0');
    final mm  = end.minute.toString().padLeft(2, '0');
    return '$hh:$mm';
  }

  // ── submit ────────────────────────────────────────────────────────────────

  Future<void> _submit() async {
    if (_submitting) return;
    setState(() { _submitting = true; _error = null; });
    try {
      await widget.api.createQueueEvent(
        durationHours : _durationHours,
        windowSeconds : _windowMinutes * 60,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  // ── build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('New Queue Session'),
        leading: const BackButton(),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // ── live-preview card ──────────────────────────────────────
            _PreviewCard(
              durationLabel: _fmtDuration(_durationHours),
              endTime      : _fmtEndTime(_durationHours),
              windowMinutes: _windowMinutes,
            ),
            const SizedBox(height: 28),

            // ── Duration ──────────────────────────────────────────────
            _SliderSection(
              icon     : Icons.timer_outlined,
              label    : 'Queue Duration',
              valueText: _fmtDuration(_durationHours),
              minLabel : '30 min',
              maxLabel : '12 hrs',
              value    : _durationHours,
              min      : 0.5,
              max      : 12.0,
              divisions: 23,
              onChanged: (v) => setState(() => _durationHours = v),
            ),
            const SizedBox(height: 28),

            // ── Driver window ──────────────────────────────────────────
            _SliderSection(
              icon     : Icons.hourglass_bottom_rounded,
              label    : 'Driver Window',
              valueText: '$_windowMinutes min',
              minLabel : '1 min',
              maxLabel : '30 min',
              value    : _windowMinutes.toDouble(),
              min      : 1,
              max      : 30,
              divisions: 29,
              onChanged: (v) => setState(() => _windowMinutes = v.round()),
            ),
            const SizedBox(height: 32),

            // ── error ──────────────────────────────────────────────────
            if (_error != null) ...[
              _ErrorBanner(message: _error!),
              const SizedBox(height: 20),
            ],

            // ── submit ─────────────────────────────────────────────────
            SizedBox(
              width : double.infinity,
              height: 52,
              child : ElevatedButton(
                onPressed: _submitting ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: AppColors.textOnPrimary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppRadius.lg),
                  ),
                  elevation: 0,
                ),
                child: _submitting
                    ? const SizedBox(
                        width : 20, height: 20,
                        child : CircularProgressIndicator(
                          strokeWidth: 2.5, color: Colors.white),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.sensors_rounded, size: 18),
                          SizedBox(width: 8),
                          Text('Create & Go Live',
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.2)),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

// ── Preview card ──────────────────────────────────────────────────────────────

class _PreviewCard extends StatelessWidget {
  final String durationLabel;
  final String endTime;
  final int    windowMinutes;

  const _PreviewCard({
    required this.durationLabel,
    required this.endTime,
    required this.windowMinutes,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding   : const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color       : AppColors.primaryLight,
      borderRadius: BorderRadius.circular(AppRadius.lg),
      border      : Border.all(color: AppColors.primary.withOpacity(0.15)),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.primary),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            'Queue will run for $durationLabel, ending ~$endTime. '
            'Each driver gets a $windowMinutes-min window per shipment.',
            style: const TextStyle(
              fontSize  : 13,
              color     : AppColors.primary,
              height    : 1.5,
            ),
          ),
        ),
      ],
    ),
  );
}

// ── Slider section ────────────────────────────────────────────────────────────

class _SliderSection extends StatelessWidget {
  final IconData             icon;
  final String               label;
  final String               valueText;
  final String               minLabel;
  final String               maxLabel;
  final double               value;
  final double               min;
  final double               max;
  final int                  divisions;
  final ValueChanged<double> onChanged;

  const _SliderSection({
    required this.icon,
    required this.label,
    required this.valueText,
    required this.minLabel,
    required this.maxLabel,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // header row
      Row(
        children: [
          Icon(icon, size: 16, color: AppColors.textSecondary),
          const SizedBox(width: 6),
          Text(label,
              style: const TextStyle(
                fontSize  : 13,
                fontWeight: FontWeight.w600,
                color     : AppColors.textSecondary,
              )),
          const Spacer(),
          Container(
            padding   : const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color       : AppColors.primaryLight,
              borderRadius: BorderRadius.circular(AppRadius.pill),
            ),
            child: Text(valueText,
                style: const TextStyle(
                  fontSize  : 13,
                  fontWeight: FontWeight.w700,
                  color     : AppColors.primary,
                )),
          ),
        ],
      ),
      const SizedBox(height: 8),
      // slider
      SliderTheme(
        data: SliderTheme.of(context).copyWith(
          activeTrackColor  : AppColors.primary,
          inactiveTrackColor: AppColors.border,
          thumbColor        : AppColors.primary,
          overlayColor      : AppColors.primary.withOpacity(0.12),
          trackHeight       : 4,
          thumbShape        : const RoundSliderThumbShape(enabledThumbRadius: 10),
          overlayShape      : const RoundSliderOverlayShape(overlayRadius: 20),
          trackShape        : const RoundedRectSliderTrackShape(),
          tickMarkShape     : SliderTickMarkShape.noTickMark,
        ),
        child: Slider(
          value    : value,
          min      : min,
          max      : max,
          divisions: divisions,
          onChanged: onChanged,
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(minLabel,
                style: const TextStyle(fontSize: 11, color: AppColors.textHint)),
            Text(maxLabel,
                style: const TextStyle(fontSize: 11, color: AppColors.textHint)),
          ],
        ),
      ),
    ],
  );
}

// ── Error banner ──────────────────────────────────────────────────────────────

class _ErrorBanner extends StatelessWidget {
  final String message;
  const _ErrorBanner({required this.message});

  @override
  Widget build(BuildContext context) => Container(
    padding   : const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color       : AppColors.errorLight,
      borderRadius: BorderRadius.circular(AppRadius.md),
    ),
    child: Row(
      children: [
        const Icon(Icons.error_outline_rounded, size: 16, color: AppColors.error),
        const SizedBox(width: 8),
        Expanded(
          child: Text(message,
              style: const TextStyle(fontSize: 13, color: AppColors.error)),
        ),
      ],
    ),
  );
}